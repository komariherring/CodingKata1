//: Playground - noun: a place where people can play

import UIKit

func divide(a: Int, b: Int) -> Bool
{
    if a % b == 0
    
    {
        return true
    }
    else
    
    {
        return false
    }
}


func theDivisors (number: Int) -> Int
{
    var divisors: Int = 0
    
    for x in 1...number
    
    {
        divide(a: number, b: x)
        
        if (divide(a: number, b: x) == true)
        {
            
            divisors = divisors + 1
            
        }
        
    }
    
    return divisors
    
}



func Prime(number: Int) -> Bool
{
    if theDivisors(number: number) == 2
    
    {
        return true
    }
    
    else
    
    {
        return false
    }
}


func printPrime(count: Int)
{
    var i = 0
    
    var theCount = 0
    
    repeat
    
    {
        i = i + 1
        
        if Prime(number: i) == true
        {
            print("Prime number: \(i)")
            
            theCount = theCount + 1
        }
    }
        while theCount < count
}


printPrime(count: 9)

func reverse( numbers: [Int]) -> [Int]
{
    // arrary name could be more descriptive 
    var Array = [Int]()
    
    Array = numbers.reversed()
    
    return Array
    
}


func timeDifference(firstHour: Int, firstMinute: Int, secondHour: Int, secondMinute: Int) -> Int
{
    let firstTime = (firstHour * 60) + firstMinute
    
    let secondTime = (secondHour * 60) + secondMinute
    
    return secondTime - firstTime
}



